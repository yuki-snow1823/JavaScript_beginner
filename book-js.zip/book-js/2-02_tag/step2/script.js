// 外部JavaScriptファイル
/*
外部JavaScriptファイルは
読み込まれたらすぐに実行されます。
*/ 
console.log('隣の客は');